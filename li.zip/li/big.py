# -*- coding:utf-8 -*-

# coding:utf-8
import pandas as pd
import matplotlib.pyplot as plot
import math

# 载入数据
def load(str):#如果报 编码错误可将数据文件改成utf-8编码
    result = pd.read_csv(str)
    return result

#替换stuSep信息
def replacemessage(firsthand, dict):
    newdata=[]
    for i in range(0, len(firsthand)):
        numdata = firsthand.iloc[i]
        i=numdata[5]
        message = i.split("/")
        message[0] = "R学院"
        if message[1] == '软件工程':
            message[1] = 'SE'
        else:
            message[1] = "NE"
        message[2] = "16"
        message[3] = dict.get(message[3])
        t = numdata[0]
        time = t.split(" ")[1].split(":")
        time1 = int(time[0])
        if time1 > 6 and time1 < 9:#判断啥时候吃的
            time = '早餐'
        elif time1>11 and time1<14 :
            time="午餐"
        elif time1>17 and time1<20:
            time='晚餐'
        else:
            time='其它'
        message.append(time)
        newdata.append(message)
    df=pd.DataFrame(newdata,columns=["college","major","grade","class","comtime"])#学院/专业/学年/班级 分四个列
    firsthand=firsthand.drop("stuSep",axis=1)
    firsthand=pd.concat([firsthand,df],axis=1)
    return firsthand
#返回不重复的班级名称字典
def banji(result):
    banji=result["stuSep"]
    result=set(banji)
    data={}
    num=1
    for i in result:
        i=i.split("/")[3]
        data[i]=num
        num+=1
    return data
#检查stuSep是否为空
def checkstuSep(data):
    dat=[]
    a=2.3
    num=0
    for i in data['stuSep']:
        if type(i)==float:

            dat.append(num)
        num+=1
    return dat
#删除一行或几行数据
def delhang(num,data):
    for i in range(0,len(num)):
        #data=data.drop(num,axis=0)
        data = data.drop(num)
    return data
# 替换一列数据
def updatelei(dat,data):
    for i in dat:
        data.iat[i,3]=dat[i]
    return data

# 填充消费数据
def filldata(data):
    num=0
    dat={}
    sum=0
    for i in data["conAmount"]:
        if math.isnan(i):
           dat[num]=sum/(num+1)
        else:
            sum+=i
        num+=1
    data=updatelei(dat,data)
    return data
    pass

#班级数据统计
def classdataStatistics(classname,data):
    print("所选班级为：16软工大数据1班")
    classdata=[]
    zao,z,w,qi=0,0,0,0
    eatmoney,othermoney=0,0
    for i in range(0,len(data)):
        numdata=data.iloc[i]
        if numdata[9]!=classname:
            continue
        else:
            classdata.append(numdata)
            if numdata[10]== '早餐':
                zao+=1
                eatmoney+=numdata[3]
            elif numdata[10]=="午餐":
                z+=1
                eatmoney += numdata[3]
            elif numdata[10]== '晚餐':
                w+=1
                eatmoney += numdata[3]
            else:
                qi+=1
                othermoney+=numdata[3]
    print("早餐次数：%d,午餐次数：%d,晚餐次数: %d,三餐消费：%.2f,三餐消费占比：%.2f,"%(zao,z,w,eatmoney,eatmoney/(eatmoney+othermoney)))
    string="早餐次数："+str(zao)+",午餐次数："+str(z)+",晚餐次数: "+str(w)+",三餐消费："+str(eatmoney)+",三餐消费占比："+str(eatmoney/(eatmoney+othermoney))+","
    saveresult(string)
    labels = [u'zaotimes', u'wutimes', u'wantimes', u'qitimes']
    sizes=[zao,z,w,othermoney]
    savefigure(labels)
    savefigure(sizes)

    labels=[u'Consumption of three meals',u'others']
    sizes=[eatmoney,othermoney]
    savefigure(labels)
    savefigure(sizes)
    return classdata

#个人数据统计
def persondataStatistics(conID,data):
    print("所选人为该班卡号为29221")
    df=pd.DataFrame(data)
    classlist={}
    classrankall={}
    classrankeat={}
    #任意选取一个同学，分析该同学在自己班级中的消费排名：一日三餐消费，全部消费，三餐消费在全部消费中的比重。
    #3）输出每一个班消费三餐消费最高、全部消费最高的十位同学。
    for i in range(0, len(df)):
        zao, z, w, qi = 0, 0, 0, 0
        conID=int(conID)
        person=[]
        persondata=df.iloc[i]
        if persondata[10] == '早餐':
            zao += persondata[3]
        elif persondata[10] == "午餐":
            z += persondata[3]
        elif persondata[10] == '晚餐':
            w += persondata[3]
        else:
            qi  += persondata[3]
        if persondata[1] not in classlist:
            person.append(zao)
            person.append(z)
            person.append(w)
            person.append(qi)
            classlist[persondata[1]] = person
        else:
            classlist.get(persondata[1])[0]=zao+classlist.get(persondata[1])[0]
            classlist.get(persondata[1])[1] = z + classlist.get(persondata[1])[1]
            classlist.get(persondata[1])[2] = w + classlist.get(persondata[1])[2]
            classlist.get(persondata[1])[3] = qi + classlist.get(persondata[1])[3]
    for i in classlist:
        sum=classlist[i][0]+classlist[i][1]+classlist[i][2]+classlist[i][3]
        classrankall[sum]=i
    for i in classlist:
        sum=classlist[i][0]+classlist[i][1]+classlist[i][2]
        classrankeat[sum]=i
    classrankall1= sorted(classrankall,reverse=True)
    classrankeat1=sorted(classrankeat,reverse=True)
    xiaofei=classlist[conID][0] + classlist[conID][1] + classlist[conID][2]
    print("消费排名 %d,三餐消费 %.2f,全部消费 %.2f,三餐消费比重 %.2f "%(classrankall1.index(xiaofei+classlist[conID][3])+1,xiaofei,xiaofei+classlist[conID][3],xiaofei/(xiaofei+classlist[conID][3]) ))
    string="消费排名 "+str(classrankall1.index(xiaofei+classlist[conID][3])+1)+",三餐消费 "+str(xiaofei)+",全部消费 "+str(xiaofei+classlist[conID][3])+",三餐消费比重 "+str(xiaofei/(xiaofei+classlist[conID][3]))+"  "
    saveresult(string)

    labels=[u'Consumption of three meals',u'others']
    sizes=[xiaofei,xiaofei+classlist[conID][3]]
    savefigure(labels)
    savefigure(sizes)
    top10=[]
    top10money=[]
    sum=0
    print("班级全部消费前10：")
    for i in range (0,len(classrankall1)):
        if i >9:
            sum += classrankall1[i]
            continue
        print(classrankall.get(classrankall1[i]),end=" ")
        top10.append(classrankall.get(classrankall1[i]))
        top10money.append(classrankall1[i])
    print("")
    string="班级全部消费前10："+str(top10[0])+","+str(top10[1])+","+str(top10[2])+","+str(top10[3])+","+str(top10[4])+","+str(top10[5])+","+str(top10[6])+","+str(top10[7])+","+str(top10[8])+","+str(top10[9])+","
    saveresult(string)
    top10.append('all class')
    top10money.append(sum)
    savefigure(top10)
    savefigure(top10money)
    top10=[]
    top10money=[]
    sum=0
    print("班级三餐消费前10：")
    for i in range (0,len(classrankeat1)):
        if i >9:
            sum+=classrankeat1[i]
            continue
        print(classrankeat.get(classrankeat1[i]),end=" ")
        top10.append(classrankeat.get(classrankeat1[i]))
        top10money.append(classrankeat1[i])
    print("")
    string = "班级三餐消费前10：" + str(top10[0]) + "," + str(top10[1]) + "," + str(top10[2]) + "," + str(top10[3]) + "," + str(
        top10[4]) + "," + str(top10[5]) + "," + str(top10[6]) + "," + str(top10[7]) + "," + str(top10[8]) + "," + str(
        top10[9]) + ","
    saveresult(string)
    top10.append('all class')
    top10money.append(sum)
    savefigure(top10)
    savefigure(top10money)
    pass

def savefigure(data):
    fileObject = open('huatu.txt', 'a')
    for i in data:
        fileObject.write(str(i))
        fileObject.write(',')
    fileObject.write('\n')
def saveresult(data):
    fileObject = open('result.txt', 'a')
    fileObject.write(data)
    fileObject.write('\n')
def huitu(labels,sizes,name):
    plot.figure(figsize=(8, 8))
    patches, l_text, p_text = plot.pie(sizes,  labels=labels,
                                       labeldistance=1.1, autopct='%2.0f%%', shadow=False,
                                       startangle=90, pctdistance=0.6)
    for t in l_text:
        t.set_size = 30
    for t in p_text:
        t.set_size = 20
    plot.axis('equal')
    plot.legend(loc='upper left', bbox_to_anchor=(-0.1, 1))
    plot.grid()
    plot.savefig(name)
    plot.show()
def readtxt():
    f=open('huatu.txt')
    num=0
    while True:
        num+=1
        stringlabels=f.readline()
        if not stringlabels:
            break
        stringsizes=f.readline()
        stringlabels=stringlabels.split(",")
        stringsizes=stringsizes.split(",")
        stringlabels=stringlabels[0:-1]
        stringsizes=stringsizes[0:-1]
        huitu(stringlabels,stringsizes,str(num)+".png")#指定分析结果图片输出路径（不能为jpg）
    print(stringlabels)
    pass
def main():
    firsthand = load("./2016soft.csv")#原数据位置
    dat = checkstuSep(firsthand)
    firsthand = delhang(dat, firsthand)#删除一行或几行数据
    firsthand = filldata(firsthand)#填充消费数据
    firsthand=firsthand.reset_index(drop=True)#还原索引
    dict = banji(firsthand)
    firsthand = replacemessage(firsthand, dict)
    firsthand.to_csv("./qingxi.csv", encoding="utf_8_sig’")#输出到csv，指定编码格式
    classdata=classdataStatistics(dict.get('16软工大数据1班'), firsthand)#选择某班
    persondataStatistics(29221, classdata)#编号选择某人
    readtxt()
    pass
if __name__ == '__main__':
    main()